@echo off
title Iniciar Sistema de Cobro - Mi Tienda
cd /d "C:\Users\LATITUDE\Desktop\Sistema de cobro Mi tienda\Mi_tienda_offline"
echo ==========================================
echo   Iniciando servidor local para "Mi Tienda"
echo ==========================================
echo.

python --version >nul 2>&1
if errorlevel 1 (
    echo ❌ Python no está instalado o no se encuentra en el PATH.
    echo Por favor instala Python desde https://www.python.org/downloads/
    pause
    exit /b
)

echo ✅ Servidor iniciado en http://localhost:8000/
timeout /t 2 >nul
start http://localhost:8000/sistemadecobro_mitienda.html
python -m http.server 8000
pause